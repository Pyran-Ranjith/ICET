</div> <!-- End of .container -->
<footer class="bg-dark text-white text-center py-3 mt-4">
    <div class="container">
        &copy; <?php echo date("Y"); ?> My PHP Project. All rights reserved.
    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
