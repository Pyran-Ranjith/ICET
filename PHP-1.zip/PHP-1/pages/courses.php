<?php include '../includes/header.php'; ?>
<h2>Our Courses</h2>
<ul>
    <li>Web Development</li>
    <li>Database Management</li>
    <li>Office Productivity</li>
</ul>
<?php include '../includes/footer.php'; ?>
