<?php include 'includes/header.php'; ?>
<!-- <h1>Welcome to My PHP Bootstrap Website</h1>
<p>This is the homepage. Use the menu to navigate.</p> -->
<?php include 'includes/footer.php'; ?>
